use std::collections::HashMap;
use std::fs::File;

use std::fs;

use std::io::prelude::*;
use text_to_png::TextRenderer;

use ::phf::{phf_map, Map};

static KANAMAP: phf::Map<&'static str, &'static str> = phf_map! {
    "A" => "A",
    "I" => "B",
    "U" => "C",
    "E" => "D",
    "O" => "E",
    "KA" => "F",
    "KI" => "G",
    "KU" => "H",
    "KE" => "I",
    "KO" => "J",
    "SA" => "K",
    "SI" => "L",
    "SU" => "M",
    "SE" => "N",
    "SO" => "O",
    "TA" => "P",
    "TI" => "Q",
    "TU" => "R",
    "TE" => "S",
    "TO" => "T",
    "MA" => "U",
    "MI" => "V",
    "MU" => "W",
    "ME" => "X",
    "MO" => "Y",
    "NA" => "Z",
    "NI" => "a",
    "NU" => "b",
    "NE" => "c",
    "NO" => "d",
    "HA" => "e",
    "HI" => "f",
    "HU" => "g",
    "HE" => "h",
    "HO" => "i",
    "N" => "j",
    "WA" => "k",
    "WO" => "l",
    "RA" => "m",
    "RI" => "n",
    "RU" => "o",
    "RE" => "p",
    "RO" => "q",
    "YA" => "r",
    "YU" => "s",
    "YO" => "t",
};

static HIRAMAP: phf::Map<&'static str, &'static str> = phf_map! {
    "A" => "A",
    "I" => "B",
    "U" => "C",
    "E" => "D",
    "O" => "E",
    "KA" => "F",
    "KI" => "G",
    "KU" => "H",
    "KE" => "I",
    "KO" => "J",
    "SA" => "K",
    "SI" => "L",
    "SU" => "M",
    "SE" => "N",
    "SO" => "O",
    "TA" => "P",
    "TI" => "Q",
    "TU" => "R",
    "TE" => "S",
    "TO" => "T",
    "NA" => "U",
    "NI" => "V",
    "NU" => "W",
    "NE" => "X",
    "NO" => "Y",
    "HA" => "Z",
    "HI" => "a",
    "HU" => "b",
    "HE" => "c",
    "HO" => "d",
    "MA" => "e",
    "MI" => "f",
    "MU" => "g",
    "ME" => "h",
    "MO" => "i",
    "YA" => "j",
    "YU" => "k",
    "YO" => "l",
    "RA" => "m",
    "RI" => "n",
    "RU" => "o",
    "RE" => "p",
    "RO" => "q",
    "WA" => "s", // XXX
    "N" => "t",
};

fn main() {
    if let Err(err) = fs::create_dir_all("katakana") {
        // return;
    }
    if let Err(err) = fs::create_dir_all("hiragana") {
        // return;
    }
    let katafont = TextRenderer::try_new_with_ttf_font_data(include_bytes!("katakana.ttf"))
        .expect("Example font is definitely loadable");
    let hirafont = TextRenderer::try_new_with_ttf_font_data(include_bytes!("hiragana.ttf"))
        .expect("Example font is definitely loadable");
    for (key, value) in &KANAMAP {
        render(&katafont, "katakana", key, 56);
        render(&hirafont, "hiragana", key, 64);
    }
}

fn render(renderer: &TextRenderer, a: &str, text: &str, size: u32) {
    let character = KANAMAP[text];
    let text_png = renderer
        .render_text_to_png_data(character, size, "Black")
        .unwrap();
    let filename = format!("{}/{}.png", a, text);
    let mut file = File::create(filename).unwrap();
    file.write_all(text_png.data.as_slice()).unwrap();
}
